
package controlador;


public class PaqueteConDetalles {
    private int idPaquete;
    private String nombrePaquete;
    private String descripcion;
    private double precio;
    private String nombreFlor;
    private int cantidad;

    // Constructor
    public PaqueteConDetalles(int idPaquete, String nombrePaquete, String descripcion, double precio, String nombreFlor, int cantidad) {
        this.idPaquete = idPaquete;
        this.nombrePaquete = nombrePaquete;
        this.descripcion = descripcion;
        this.precio = precio;
        this.nombreFlor = nombreFlor;
        this.cantidad = cantidad;
    }

    // Getters y Setters
    public int getIdPaquete() {
        return idPaquete;
    }

    public void setIdPaquete(int idPaquete) {
        this.idPaquete = idPaquete;
    }

    public String getNombrePaquete() {
        return nombrePaquete;
    }

    public void setNombrePaquete(String nombrePaquete) {
        this.nombrePaquete = nombrePaquete;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getNombreFlor() {
        return nombreFlor;
    }

    public void setNombreFlor(String nombreFlor) {
        this.nombreFlor = nombreFlor;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
}
