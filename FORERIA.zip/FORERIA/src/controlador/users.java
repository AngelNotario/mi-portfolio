/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;


public class users {
    
  public void llenarUsers(JComboBox comboBox) {
    conexion con = new conexion();
    Connection cn = con.conectar();
    
    String sql = "SELECT Nombre FROM users";
    
    try {
        PreparedStatement ps = cn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        
        while (rs.next()) {
            comboBox.addItem(rs.getString("Nombre"));
        }
        
        rs.close();
        ps.close();
        cn.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al llenar el JComboBox : " + e.getMessage());
    }
}  
  
  public boolean autentificacion(String usuario, String pass){
        
    conexion con = new conexion();
    Connection cn = con.conectar();
    
        try {
                
                PreparedStatement ps = cn.prepareStatement("select id_usuario from users where Nombre='"+usuario+"' AND password='"+pass+"'");
                ResultSet rs = ps.executeQuery();
                              
                if(rs.next()){
                        return true;
                               
                
                } 
                
                
                else{JOptionPane.showMessageDialog(null, "* * * USUARIO O CONTRASEÑA \nINCORRECTA, FAVOR DE VERIFICAR * * * ");
                
                    return false;
               
                     }
                
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "error al iniciar sesion" +e);
                 return false;
                
            }
    
    }
}
