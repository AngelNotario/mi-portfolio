
package controlador;
import com.toedter.calendar.JDateChooser;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.time.LocalDateTime;
import java.util.Date;
public class pedidos {
 

    public  boolean validacionFecha(Date date) {
        Date currentDate = new Date();        
        return !date.before(currentDate);
    }  
    
public boolean registrarPedido(String nombreCliente, String nombreVendedor, String nombreRuta, java.sql.Date fecha, String nombrePaquete, int cantidad, double total) {
    int idCliente = obtenerIdCliente(nombreCliente);
    int idVendedor = obtenerIdVendedor(nombreVendedor);
    int idRuta = obtenerIdRuta(nombreRuta);
    int idPaquete = obtenerIdPaquete(nombrePaquete);

    if (idCliente == -1 || idVendedor == -1 || idRuta == -1 || idPaquete == -1) {
        JOptionPane.showMessageDialog(null, "Error al obtener IDs de las llaves foráneas.");
        return false;
    }

    conexion con = new conexion();
    Connection cn = con.conectar();

    if (cn == null) {
        JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos.");
        return false;
    }

    try {
        cn.setAutoCommit(false);

        String consultaPedido = "INSERT INTO pedidos (id_cliente, id_vendedor, id_ruta, fecha) VALUES (?, ?, ?, ?)";
        PreparedStatement psPedido = cn.prepareStatement(consultaPedido, Statement.RETURN_GENERATED_KEYS);
        psPedido.setInt(1, idCliente);
        psPedido.setInt(2, idVendedor);
        psPedido.setInt(3, idRuta);
        psPedido.setDate(4, new java.sql.Date(fecha.getTime()));

        int filasInsertadasPedido = psPedido.executeUpdate();
        
        if (filasInsertadasPedido > 0) {
            ResultSet rsPedido = psPedido.getGeneratedKeys();
            int idPedido = 0;
            if (rsPedido.next()) {
                idPedido = rsPedido.getInt(1);
            }

            String consultaDetalle = "INSERT INTO detalle_pedido (id_pedido, id_paquete, cantidad, total) VALUES (?, ?, ?, ?)";
            PreparedStatement psDetalle = cn.prepareStatement(consultaDetalle);
            psDetalle.setInt(1, idPedido);
            psDetalle.setInt(2, idPaquete);
            psDetalle.setInt(3, cantidad);
            psDetalle.setDouble(4, total);

            int filasInsertadasDetalle = psDetalle.executeUpdate();

            if (filasInsertadasDetalle > 0) {
                cn.commit();
                JOptionPane.showMessageDialog(null, "Pedido registrado correctamente.");
                return true;
            } else {
                cn.rollback();
                JOptionPane.showMessageDialog(null, "Error al registrar el detalle del pedido.");
                return false;
            }
        } else {
            cn.rollback();
            JOptionPane.showMessageDialog(null, "Error al registrar el pedido.");
            return false;
        }
    } catch (SQLException e) {
        try {
            cn.rollback();
        } catch (SQLException ex) {
            System.out.println("Error al revertir la transacción: " + ex.getMessage());
        }
        JOptionPane.showMessageDialog(null, "Error SQL al registrar pedido: " + e.getMessage());
        return false;
    } finally {
        try {
            cn.setAutoCommit(true);
        } catch (SQLException e) {
            System.out.println("Error al restablecer el auto-commit: " + e.getMessage());
        }
    }
}
 
private int obtenerIdCliente(String nombreCliente) {
    conexion con = new conexion();
    Connection cn = con.conectar();

    if (cn == null) {
        JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos.");
        return -1;
    }

    String sql = "SELECT id_cliente FROM clientes WHERE nombre = ?";
    try {
        PreparedStatement ps = cn.prepareStatement(sql);
        ps.setString(1, nombreCliente);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            return rs.getInt("id_cliente");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al obtener el ID del cliente: " + e.getMessage());
    }
    return -1; 
}

private int obtenerIdVendedor(String nombreVendedor) {
    conexion con = new conexion();
      Connection cn = con.conectar();

    if (cn == null) {
        JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos.");
        return -1;
    }

    String sql = "SELECT id_vendedor FROM vendedores WHERE nombre = ?";
    try {
        PreparedStatement ps = cn.prepareStatement(sql);
        ps.setString(1, nombreVendedor);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            return rs.getInt("id_vendedor");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al obtener el ID del vendedor: " + e.getMessage());
    }
    return -1; 
}

private int obtenerIdRuta(String nombreRuta) {
    conexion con = new conexion();
     Connection cn = con.conectar();

    if (cn == null) {
        JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos.");
        return -1;
    }

    String sql = "SELECT id_ruta FROM ruta WHERE nombre_ruta = ?";
    try {
        PreparedStatement ps = cn.prepareStatement(sql);
        ps.setString(1, nombreRuta);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            return rs.getInt("id_ruta");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al obtener el ID de la ruta: " + e.getMessage());
    }
    return -1; 
}

private int obtenerIdPaquete(String nombrePaquete) {
    conexion con = new conexion();
    Connection cn = con.conectar();

    if (cn == null) {
        JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos.");
        return -1;
    }

    String sql = "SELECT id_paquete FROM paquetes WHERE nombre_paquete = ?";
    try {
        PreparedStatement ps = cn.prepareStatement(sql);
        ps.setString(1, nombrePaquete);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            return rs.getInt("id_paquete");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al obtener el ID del paquete: " + e.getMessage());
    }
    return -1; 
}

public void llenarComboClientes(JComboBox<String> comboBox) {
    conexion con = new conexion();
    Connection cn = con.conectar();
    
    String sql = "SELECT nombre FROM clientes";
    
    try {
        PreparedStatement ps = cn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        
        while (rs.next()) {
            comboBox.addItem(rs.getString("nombre"));
        }
        
        rs.close();
        ps.close();
        cn.close();
    } catch (SQLException e) {
        System.out.println("Error al llenar el JComboBox de clientes: " + e.getMessage());
    }
}

public void llenarComboVendedores(JComboBox<String> comboBox) {
    conexion con = new conexion();
    Connection cn = con.conectar();
    
    String sql = "SELECT nombre FROM vendedores";
    
    try {
        PreparedStatement ps = cn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        
        while (rs.next()) {
            comboBox.addItem(rs.getString("nombre"));
        }
        
        rs.close();
        ps.close();
        cn.close();
    } catch (SQLException e) {
        System.out.println("Error al llenar el JComboBox de vendedores: " + e.getMessage());
    }
}

public void llenarComboRutas(JComboBox<String> comboBox) {
    conexion con = new conexion();
    Connection cn = con.conectar();
    
    String sql = "SELECT nombre_ruta FROM ruta";
    
    try {
        PreparedStatement ps = cn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        
        while (rs.next()) {
            comboBox.addItem(rs.getString("nombre_ruta"));
        }
        
        rs.close();
        ps.close();
        cn.close();
    } catch (SQLException e) {
        System.out.println("Error al llenar el JComboBox de rutas: " + e.getMessage());
    }
}

public void llenarComboPaquetes(JComboBox<String> comboBox) {
    conexion con = new conexion();
    Connection cn = con.conectar();
    
    String sql = "SELECT nombre_paquete FROM paquetes";
    
    try {
        PreparedStatement ps = cn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        
        while (rs.next()) {
            comboBox.addItem(rs.getString("nombre_paquete"));
        }
        
        rs.close();
        ps.close();
        cn.close();
    } catch (SQLException e) {
        System.out.println("Error al llenar el JComboBox de paquetes: " + e.getMessage());
    }
}

public void mostrarPedidos(JTable table) {
    conexion con = new conexion();
    Connection cn = con.conectar();

    if (cn == null) {
        JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos.");
        return;
    }

    DefaultTableModel modelo = new DefaultTableModel();
    TableRowSorter<TableModel> ordenarTabla = new TableRowSorter<>(modelo);
    table.setRowSorter(ordenarTabla);

    modelo.addColumn("ID Pedido");
    modelo.addColumn("Cliente");
    modelo.addColumn("Vendedor");
    modelo.addColumn("Ruta");
    modelo.addColumn("Fecha");
    modelo.addColumn("Paquete");
    modelo.addColumn("Cantidad");
    modelo.addColumn("Total");

    table.setModel(modelo);

    String sql = "SELECT p.id_pedido, c.nombre AS cliente, v.nombre AS vendedor, r.nombre_ruta AS ruta, p.fecha, " +
                 "pa.nombre_paquete AS paquete, dp.cantidad, dp.total " +
                 "FROM pedidos p " +
                 "INNER JOIN clientes c ON p.id_cliente = c.id_cliente " +
                 "INNER JOIN vendedores v ON p.id_vendedor = v.id_vendedor " +
                 "INNER JOIN ruta r ON p.id_ruta = r.id_ruta " +
                 "INNER JOIN detalle_pedido dp ON p.id_pedido = dp.id_pedido " +
                 "INNER JOIN paquetes pa ON dp.id_paquete = pa.id_paquete";
    try {
        PreparedStatement ps = cn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        Object[] datos = new Object[8];
        while (rs.next()) {
            datos[0] = rs.getInt("id_pedido");
            datos[1] = rs.getString("cliente");
            datos[2] = rs.getString("vendedor");
            datos[3] = rs.getString("ruta");
            datos[4] = rs.getDate("fecha");
            datos[5] = rs.getString("paquete");
            datos[6] = rs.getInt("cantidad");
            datos[7] = rs.getDouble("total");
            modelo.addRow(datos);
        }
        table.setModel(modelo);
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al mostrar los registros: " + e.getMessage());
        e.printStackTrace();
    }
}

public void calcularTotal(JComboBox<String> comboPaquetes, JComboBox<String> comboRutas, JTextField txtCantidad, JTextField txtTotal) {
    String nombrePaquete = (String) comboPaquetes.getSelectedItem();
    String nombreRuta = (String) comboRutas.getSelectedItem();
    int cantidad = Integer.parseInt(txtCantidad.getText());

    double precioPaquete = obtenerPrecioPaquete(nombrePaquete);
    double costoRuta = obtenerCostoRuta(nombreRuta);

    System.out.println("Precio Paquete: " + precioPaquete);
    System.out.println("Costo Ruta: " + costoRuta);

    if (precioPaquete == -1 || costoRuta == -1) {
        JOptionPane.showMessageDialog(null, "Error al obtener el precio del paquete o el costo de la ruta.");
        return;
    }

    double total = (precioPaquete + costoRuta) * cantidad ;
    txtTotal.setText(String.valueOf(total));
}

private double obtenerPrecioPaquete(String nombrePaquete) {
    conexion con = new conexion();
    Connection cn = con.conectar();

    if (cn == null) {
        JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos.");
        return -1;
    }

    String sql = "SELECT precio FROM paquetes WHERE nombre_paquete = ?";
    try {
        PreparedStatement ps = cn.prepareStatement(sql);
        ps.setString(1, nombrePaquete);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            double precio = rs.getDouble("precio");
            rs.close();
            ps.close();
            cn.close();
            return precio;
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al obtener el precio del paquete: " + e.getMessage());
    }
    return -1; 
}

private double obtenerCostoRuta(String nombreRuta) {
    conexion con = new conexion();
    Connection cn = con.conectar();

    if (cn == null) {
        JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos.");
        return -1;
    }

    String sql = "SELECT costo_envio FROM ruta WHERE nombre_ruta = ?";
    try {
        PreparedStatement ps = cn.prepareStatement(sql);
        ps.setString(1, nombreRuta);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            double costo = rs.getDouble("costo_envio");
            rs.close();
            ps.close();
            cn.close();
            return costo;
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al obtener el costo de la ruta: " + e.getMessage());
    }
    return -1; 
}

public void rellenarCamposPedido(JTable table, JComboBox<String> comboClientes, JComboBox<String> comboVendedores, JComboBox<String> comboRutas, JDateChooser dateChooser, JComboBox<String> comboPaquetes, JTextField txtCantidad, JTextField txtTotal) {
    DefaultTableModel modelo = (DefaultTableModel) table.getModel();
    int filaSeleccionada = table.getSelectedRow();
    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(null, "Selecciona un pedido para modificar.");
        return;
    } else {
      
        int idPedido = (int) modelo.getValueAt(filaSeleccionada, 0);
        String cliente = (String) modelo.getValueAt(filaSeleccionada, 1);
        String vendedor = (String) modelo.getValueAt(filaSeleccionada, 2);
        String ruta = (String) modelo.getValueAt(filaSeleccionada, 3);
        Date fecha = (Date) modelo.getValueAt(filaSeleccionada, 4);
        String paquete = (String) modelo.getValueAt(filaSeleccionada, 5);
        int cantidad = (int) modelo.getValueAt(filaSeleccionada, 6);
        double total = (double) modelo.getValueAt(filaSeleccionada, 7);

        
        seleccionarComboItem(comboClientes, cliente);
        seleccionarComboItem(comboVendedores, vendedor);
        seleccionarComboItem(comboRutas, ruta);
        dateChooser.setDate(fecha);
        seleccionarComboItem(comboPaquetes, paquete);
        txtCantidad.setText(String.valueOf(cantidad));
        txtTotal.setText(String.valueOf(total));
    }
}

private void seleccionarComboItem(JComboBox<String> comboBox, String item) {
    for (int i = 0; i < comboBox.getItemCount(); i++) {
        if (comboBox.getItemAt(i).equals(item)) {
            comboBox.setSelectedIndex(i);
            break;
        }
    }
}

public boolean eliminarPedido(JTable table) {
        DefaultTableModel modelo = (DefaultTableModel) table.getModel();
        int filaSeleccionada = table.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(null, "Selecciona un pedido para eliminar.");
            return false;
        } else {
            int idPedido = (int) modelo.getValueAt(filaSeleccionada, 0);
            conexion con = new conexion();
            Connection cn = con.conectar();

            if (cn == null) {
                JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos.");
                return false;
            }

            try {
                
                cn.setAutoCommit(false);

             
                String consultaDetalle = "DELETE FROM detalle_pedido WHERE id_pedido = ?";
                PreparedStatement psDetalle = cn.prepareStatement(consultaDetalle);
                psDetalle.setInt(1, idPedido);

                int filasEliminadasDetalle = psDetalle.executeUpdate();

                
                String consultaPedido = "DELETE FROM pedidos WHERE id_pedido = ?";
                PreparedStatement psPedido = cn.prepareStatement(consultaPedido);
                psPedido.setInt(1, idPedido);

                int filasEliminadasPedido = psPedido.executeUpdate();

                if (filasEliminadasDetalle > 0 && filasEliminadasPedido > 0) {
                 
                    cn.commit();
                    JOptionPane.showMessageDialog(null, "Pedido eliminado correctamente.");
                    modelo.removeRow(filaSeleccionada); // Eliminar la fila de la tabla
                    return true;
                } else {
                   
                    cn.rollback();
                    JOptionPane.showMessageDialog(null, "Error al eliminar el pedido.");
                    return false;
                }
            } catch (SQLException e) {
                try {
                    cn.rollback();
                } catch (SQLException ex) {
                    System.out.println("Error al revertir la transacción: " + ex.getMessage());
                }
                JOptionPane.showMessageDialog(null, "Error al eliminar pedido: " + e.getMessage());
                return false;
            } finally {
                try {
                    cn.setAutoCommit(true);
                } catch (SQLException e) {
                    System.out.println("Error al restablecer el auto-commit: " + e.getMessage());
                }
            }
        }
    }

public boolean modificarPedido(JTable table, JComboBox<String> comboClientes, JComboBox<String> comboVendedores, JComboBox<String> comboRutas, JDateChooser dateChooser, JComboBox<String> comboPaquetes, JTextField txtCantidad, JTextField txtTotal) {
    DefaultTableModel modelo = (DefaultTableModel) table.getModel();
    int filaSeleccionada = table.getSelectedRow();
    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(null, "Selecciona un pedido para modificar.");
        return false; 
    } else {
        int idPedido = (int) modelo.getValueAt(filaSeleccionada, 0);
        String nombreCliente = comboClientes.getSelectedItem().toString();
        String nombreVendedor = comboVendedores.getSelectedItem().toString();
        String nombreRuta = comboRutas.getSelectedItem().toString();
        java.sql.Date fecha = new java.sql.Date(dateChooser.getDate().getTime());
        String nombrePaquete = comboPaquetes.getSelectedItem().toString();
        int cantidad = Integer.parseInt(txtCantidad.getText());
        double total = Double.parseDouble(txtTotal.getText());


        int idCliente = obtenerIdCliente(nombreCliente);
        int idVendedor = obtenerIdVendedor(nombreVendedor);
        int idRuta = obtenerIdRuta(nombreRuta);
        int idPaquete = obtenerIdPaquete(nombrePaquete);

        if (idCliente == -1 || idVendedor == -1 || idRuta == -1 || idPaquete == -1) {
            JOptionPane.showMessageDialog(null, "Error al obtener IDs de las llaves foráneas.");
            return false;
        }

        conexion con = new conexion();
        Connection cn = con.conectar();

        if (cn == null) {
            JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos.");
            return false;
        }

        try {
           
            cn.setAutoCommit(false);

            
            String consultaPedido = "UPDATE pedidos SET id_cliente = ?, id_vendedor = ?, id_ruta = ?, fecha = ? WHERE id_pedido = ?";
            PreparedStatement psPedido = cn.prepareStatement(consultaPedido);
            psPedido.setInt(1, idCliente);
            psPedido.setInt(2, idVendedor);
            psPedido.setInt(3, idRuta);
            psPedido.setDate(4, fecha);
            psPedido.setInt(5, idPedido);

            int filasModificadasPedido = psPedido.executeUpdate();

            
            String consultaDetalle = "UPDATE detalle_pedido SET id_paquete = ?, cantidad = ?, total = ? WHERE id_pedido = ?";
            PreparedStatement psDetalle = cn.prepareStatement(consultaDetalle);
            psDetalle.setInt(1, idPaquete);
            psDetalle.setInt(2, cantidad);
            psDetalle.setDouble(3, total);
            psDetalle.setInt(4, idPedido);

            int filasModificadasDetalle = psDetalle.executeUpdate();

            if (filasModificadasPedido > 0 && filasModificadasDetalle > 0) {
                cn.commit();
                JOptionPane.showMessageDialog(null, "Pedido modificado correctamente.");
                
                modelo.setValueAt(nombreCliente, filaSeleccionada, 1);
                modelo.setValueAt(nombreVendedor, filaSeleccionada, 2);
                modelo.setValueAt(nombreRuta, filaSeleccionada, 3);
                modelo.setValueAt(fecha, filaSeleccionada, 4);
                modelo.setValueAt(nombrePaquete, filaSeleccionada, 5);
                modelo.setValueAt(cantidad, filaSeleccionada, 6);
                modelo.setValueAt(total, filaSeleccionada, 7);
                return true;
            } else {
                cn.rollback();
                JOptionPane.showMessageDialog(null, "Error al modificar pedido.");
                return false;
            }
        } catch (SQLException e) {
            try {
                cn.rollback();
            } catch (SQLException ex) {
                System.out.println("Error al revertir la transacción: " + ex.getMessage());
            }
            JOptionPane.showMessageDialog(null, "Error al modificar pedido: " + e.getMessage());
            return false;
        } finally {
            try {
                cn.setAutoCommit(true);
            } catch (SQLException e) {
                System.out.println("Error al restablecer el auto-commit: " + e.getMessage());
            }
        }
    }
}



}

