
package controlador;

import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;


public class flores {
 
public boolean registrarFlor(String nombre, String tipo, String color, double precio) {
   
    

    conexion con = new conexion();
    Connection cn = con.conectar();

    if (cn == null) {
        JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos.");
        return false;
    }

    try {
        String consulta = "INSERT INTO flores (nombre, tipo, color, precio) VALUES (?, ?, ?, ?)";
        PreparedStatement ps = cn.prepareStatement(consulta);
        ps.setString(1, nombre);
        ps.setString(2, tipo);
        ps.setString(3, color);
        ps.setDouble(4, precio);
        
        int filasInsertadas = ps.executeUpdate();
        if (filasInsertadas > 0) {
            JOptionPane.showMessageDialog(null, "Flor registrada correctamente.");
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Error al registrar flor.");
            return false;
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error SQL al registrar flor: " + e.getMessage());
        return false;
    }
}

public boolean modificarFlor(JTable table, JTextField txtNombre, JTextField txtTipo, JTextField txtColor, JTextField txtPrecio) {
    DefaultTableModel modelo = (DefaultTableModel) table.getModel();
    int filaSeleccionada = table.getSelectedRow();
    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(null, "Selecciona una flor para modificar.");
        return false; // No se seleccionó ninguna fila, no se puede modificar
    } else {
        int idFlor = (int) modelo.getValueAt(filaSeleccionada, 0);
        String nombre = txtNombre.getText();
        String tipo = txtTipo.getText();
        String color = txtColor.getText();
        double precio = Double.parseDouble(txtPrecio.getText());

        // Validar el precio
        if (precio <= 0) {
            JOptionPane.showMessageDialog(null, "El precio debe ser un valor positivo.");
            return false;
        }

        conexion con = new conexion();
    Connection cn = con.conectar();

        if (cn == null) {
            JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos.");
            return false;
        }

        try {
            String consulta = "UPDATE flores SET nombre=?, tipo=?, color=?, precio=? WHERE id_flor=?";
            PreparedStatement ps = cn.prepareStatement(consulta);
            ps.setString(1, nombre);
            ps.setString(2, tipo);
            ps.setString(3, color);
            ps.setDouble(4, precio);
            ps.setInt(5, idFlor);
            
            int filasModificadas = ps.executeUpdate();
            if (filasModificadas > 0) {
                JOptionPane.showMessageDialog(null, "Flor modificada correctamente.");
                // Actualizar los datos en la tabla
                modelo.setValueAt(nombre, filaSeleccionada, 1);
                modelo.setValueAt(tipo, filaSeleccionada, 2);
                modelo.setValueAt(color, filaSeleccionada, 3);
                modelo.setValueAt(precio, filaSeleccionada, 4);
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Error al modificar flor.");
                return false;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar flor: " + e.getMessage());
            return false;
        }
    }
}

public boolean eliminarFlor(JTable table) {
    DefaultTableModel modelo = (DefaultTableModel) table.getModel();
    int filaSeleccionada = table.getSelectedRow();
    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(null, "Selecciona una flor para eliminar.");
        return false; // No se seleccionó ninguna fila, no se puede eliminar
    } else {
        int idFlor = (int) modelo.getValueAt(filaSeleccionada, 0);
         conexion con = new conexion();
         Connection cn = con.conectar();

        if (cn == null) {
            JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos.");
            return false;
        }

        try {
            String consulta = "DELETE FROM flores WHERE id_flor = ?";
            PreparedStatement ps = cn.prepareStatement(consulta);
            ps.setInt(1, idFlor);
            
            int filasEliminadas = ps.executeUpdate();
            if (filasEliminadas > 0) {
                JOptionPane.showMessageDialog(null, "Flor eliminada correctamente.");
                modelo.removeRow(filaSeleccionada); // Eliminar la fila de la tabla
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Error al eliminar flor.");
                return false;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar flor: " + e.getMessage());
            return false;
        }
    }
}

public void mostrarFlores(JTable table) {
        conexion con = new conexion();
        Connection cn = con.conectar();

    if (cn == null) {
        JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos.");
        return;
    }

    DefaultTableModel modelo = new DefaultTableModel();
    TableRowSorter<TableModel> ordenarTabla = new TableRowSorter<TableModel>(modelo);
    table.setRowSorter(ordenarTabla);

    modelo.addColumn("ID Flor");
    modelo.addColumn("Nombre");
    modelo.addColumn("Tipo");
    modelo.addColumn("Color");
    modelo.addColumn("Precio");

    table.setModel(modelo);

    String sql = "SELECT * FROM flores";
    try {
        PreparedStatement ps = cn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        Object[] datos = new Object[5];
        while (rs.next()) {
            datos[0] = rs.getInt("id_flor");
            datos[1] = rs.getString("nombre");
            datos[2] = rs.getString("tipo");
            datos[3] = rs.getString("color");
            datos[4] = rs.getDouble("precio");
            modelo.addRow(datos);
        }
        table.setModel(modelo);
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al mostrar los registros: " + e.getMessage());
        e.printStackTrace();
    }
}

 public void rellenarCamposFlor(JTable table, JTextField txtNombre, JTextField txtTipo, JTextField txtColor, JTextField txtPrecio) {
    DefaultTableModel modelo = (DefaultTableModel) table.getModel();
    int filaSeleccionada = table.getSelectedRow();
    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(null, "Selecciona una flor para modificar.");
        return; 
    } else {
        Flor flor = new Flor(
            (int) modelo.getValueAt(filaSeleccionada, 0), 
            (String) modelo.getValueAt(filaSeleccionada, 1), 
            (String) modelo.getValueAt(filaSeleccionada, 2), 
            (String) modelo.getValueAt(filaSeleccionada, 3), 
            Double.parseDouble(modelo.getValueAt(filaSeleccionada, 4).toString()) 
        );

        // Rellenar los campos del formulario
        txtNombre.setText(flor.getNombre());
        txtTipo.setText(flor.getTipo());
        txtColor.setText(flor.getColor());
        txtPrecio.setText(String.valueOf(flor.getPrecio()));
    }
}
   
}
