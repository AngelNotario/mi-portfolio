
package controlador;

import java.sql.*;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;


public class paquetes {

public boolean esDOuble(String str) {
    try {
        Double.parseDouble(str);
        return true;
    } catch (NumberFormatException e) {
        return false;
    }
}

public boolean esInt(String str) {
    try {
        Integer.parseInt(str);
        return true;
    } catch (NumberFormatException e) {
        return false;
    }
}

public boolean registrarPaqueteConDetalles(String nombrePaquete, String descripcion, double precio, int idFlor, int cantidad) {
    // Validar el precio
    if (precio <= 0) {
        JOptionPane.showMessageDialog(null, "El precio debe ser un valor positivo.");
        return false;
    }

    // Validar la cantidad
    if (cantidad <= 0) {
        JOptionPane.showMessageDialog(null, "La cantidad debe ser un valor positivo.");
        return false;
    }

    conexion con = new conexion();
    Connection cn = con.conectar();

    if (cn == null) {
        JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos.");
        return false;
    }
    
    try {
        // Iniciar transacción
        cn.setAutoCommit(false);

        // Insertar el paquete
        String consultaPaquete = "INSERT INTO paquetes (nombre_paquete, descripcion, precio) VALUES (?, ?, ?)";
        PreparedStatement psPaquete = cn.prepareStatement(consultaPaquete, Statement.RETURN_GENERATED_KEYS);
        psPaquete.setString(1, nombrePaquete);
        psPaquete.setString(2, descripcion);
        psPaquete.setDouble(3, precio);
        
        int filasInsertadasPaquete = psPaquete.executeUpdate();
        
        if (filasInsertadasPaquete > 0) {
            // Obtener el ID del paquete recién insertado
            ResultSet rsPaquete = psPaquete.getGeneratedKeys();
            int idPaquete = 0;
            if (rsPaquete.next()) {
                idPaquete = rsPaquete.getInt(1);
            }
            
            // Insertar el detalle del paquete
            String consultaDetalle = "INSERT INTO detalle_paquete (id_paquete, id_flor, cantidad) VALUES (?, ?, ?)";
            PreparedStatement psDetalle = cn.prepareStatement(consultaDetalle);
            psDetalle.setInt(1, idPaquete);
            psDetalle.setInt(2, idFlor);
            psDetalle.setInt(3, cantidad);
            
            int filasInsertadasDetalle = psDetalle.executeUpdate();
            
            if (filasInsertadasDetalle > 0) {
                // Confirmar transacción
                cn.commit();
                System.out.println("Paquete y detalle registrado correctamente.");
                return true;
            } else {
                // Revertir transacción
                cn.rollback();
                System.out.println("Error al registrar el detalle del paquete.");
                return false;
            }
        } else {
            // Revertir transacción
            cn.rollback();
            System.out.println("Error al registrar el paquete.");
            return false;
        }
    } catch (SQLException e) {
        try {
            // Revertir transacción en caso de error
            cn.rollback();
        } catch (SQLException ex) {
            System.out.println("Error al revertir la transacción: " + ex.getMessage());
        }
        System.out.println("Error SQL al registrar paquete y detalle: " + e.getMessage());
        return false;
    } finally {
        try {
            cn.setAutoCommit(true);
        } catch (SQLException e) {
            System.out.println("Error al restablecer el auto-commit: " + e.getMessage());
        }
    }
}

public void llenarComboFlores(JComboBox comboBox) {
    conexion con = new conexion();
    Connection cn = con.conectar();
    
    String sql = "SELECT nombre FROM flores";
    
    try {
        PreparedStatement ps = cn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        
        while (rs.next()) {
            comboBox.addItem(rs.getString("nombre"));
        }
        
        rs.close();
        ps.close();
        cn.close();
    } catch (SQLException e) {
        System.out.println("Error al llenar el JComboBox de proveedores: " + e.getMessage());
    }
}

public int buscarIdFLor(String nombreFlor) {
   conexion con = new conexion();
    Connection cn = con.conectar();
    
    String sql = "SELECT id_flor FROM flores WHERE nombre = ?";
    
    try {
        PreparedStatement ps = cn.prepareStatement(sql);
        ps.setString(1, nombreFlor);
        ResultSet rs = ps.executeQuery();
        
        if (rs.next()) {
            int idflor = rs.getInt("id_flor");
            rs.close();
            ps.close();
            cn.close();
            return idflor;
        } else {
            System.out.println("No se encontró la flor con el nombre: " + nombreFlor);
            return 0;
        }
    } catch (SQLException e) {
        System.out.println("Error al buscar el ID de flores: " + e.getMessage());
        return 0; 
    }
}

public void mostrarPaquetes(JTable table) {
    conexion con = new conexion();
    Connection cn = con.conectar();

    if (cn == null) {
        JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos.");
        return;
    }

    DefaultTableModel modelo = new DefaultTableModel();
    TableRowSorter<TableModel> ordenarTabla = new TableRowSorter<TableModel>(modelo);
    table.setRowSorter(ordenarTabla);

    modelo.addColumn("ID Paquete");
    modelo.addColumn("Nombre del Paquete");
    modelo.addColumn("Descripción");
    modelo.addColumn("Precio");
    modelo.addColumn("Nombre de la Flor");
    modelo.addColumn("Cantidad");

    table.setModel(modelo);

    String sql = "SELECT p.id_paquete, p.nombre_paquete, p.descripcion, p.precio, f.nombre AS nombre_flor, dp.cantidad " +
                 "FROM paquetes p " +
                 "INNER JOIN detalle_paquete dp ON p.id_paquete = dp.id_paquete " +
                 "INNER JOIN flores f ON dp.id_flor = f.id_flor";

    try {
        PreparedStatement ps = cn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        Object[] datos = new Object[6];
        while (rs.next()) {
            datos[0] = rs.getInt("id_paquete");
            datos[1] = rs.getString("nombre_paquete");
            datos[2] = rs.getString("descripcion");
            datos[3] = rs.getDouble("precio");
            datos[4] = rs.getString("nombre_flor");
            datos[5] = rs.getInt("cantidad");
            modelo.addRow(datos);
        }
        table.setModel(modelo);
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al mostrar los registros: " + e.getMessage());
        e.printStackTrace(); 
    }
}

public void rellenarCamposPaquete(JTable table, JTextField txtNombre, JTextField txtDescripcion, JTextField txtPrecio, JComboBox comboFlores, JTextField txtStock) {
    DefaultTableModel modelo = (DefaultTableModel) table.getModel();
    int filaSeleccionada = table.getSelectedRow();
    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(null, "Selecciona un paquete para modificar.");
        return; 
    } else {
        
        PaqueteConDetalles paquete = new PaqueteConDetalles(
            (int) modelo.getValueAt(filaSeleccionada, 0), 
            (String) modelo.getValueAt(filaSeleccionada, 1), 
            (String) modelo.getValueAt(filaSeleccionada, 2), 
            Double.parseDouble(modelo.getValueAt(filaSeleccionada, 3).toString()), 
            (String) modelo.getValueAt(filaSeleccionada, 4), // nombreFlor
            Integer.parseInt(modelo.getValueAt(filaSeleccionada, 5).toString()) 
        );

        
        txtNombre.setText(paquete.getNombrePaquete());
        txtDescripcion.setText(paquete.getDescripcion());
        txtPrecio.setText(String.valueOf(paquete.getPrecio()));
        txtStock.setText(String.valueOf(paquete.getCantidad()));

        
        for (int i = 0; i < comboFlores.getItemCount(); i++) {
            if (comboFlores.getItemAt(i).toString().equals(paquete.getNombreFlor())) {
                comboFlores.setSelectedIndex(i);
                break;
            }
        }
    }
}
private int obtenerIdFlor(String nombreFlor) {
    conexion con = new conexion();
    Connection cn = con.conectar();

    if (cn == null) {
        JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos.");
        return -1;
    }

    String sql = "SELECT id_flor FROM flores WHERE nombre = ?";
    try {
        PreparedStatement ps = cn.prepareStatement(sql);
        ps.setString(1, nombreFlor);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            return rs.getInt("id_flor");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al obtener el ID de la flor: " + e.getMessage());
    }
    return -1; 
}

public boolean modificarPaquete(JTable table, JTextField txtNombre, JTextField txtDescripcion, JTextField txtPrecio, JComboBox comboFlores, JTextField txtStock) {
    DefaultTableModel modelo = (DefaultTableModel) table.getModel();
    int filaSeleccionada = table.getSelectedRow();
    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(null, "Selecciona un paquete para modificar.");
        return false; 
    } else {
        int idPaquete = (int) modelo.getValueAt(filaSeleccionada, 0);
        String nombrePaquete = txtNombre.getText();
        String descripcion = txtDescripcion.getText();
        double precio = Double.parseDouble(txtPrecio.getText());
        String nombreFlor = comboFlores.getSelectedItem().toString();
        int cantidad = Integer.parseInt(txtStock.getText());

       
        if (precio <= 0) {
            JOptionPane.showMessageDialog(null, "El precio debe ser un valor positivo.");
            return false;
        }

        
        if (cantidad <= 0) {
            JOptionPane.showMessageDialog(null, "La cantidad debe ser un valor positivo.");
            return false;
        }

        
        int idFlor = obtenerIdFlor(nombreFlor);
        if (idFlor == -1) {
            JOptionPane.showMessageDialog(null, "La flor proporcionada no existe.");
            return false;
        }

       conexion con = new conexion();
    Connection cn = con.conectar();

        if (cn == null) {
            JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos.");
            return false;
        }

        try {
           
            cn.setAutoCommit(false);

           
            String consultaPaquete = "UPDATE paquetes SET nombre_paquete=?, descripcion=?, precio=? WHERE id_paquete=?";
            PreparedStatement psPaquete = cn.prepareStatement(consultaPaquete);
            psPaquete.setString(1, nombrePaquete);
            psPaquete.setString(2, descripcion);
            psPaquete.setDouble(3, precio);
            psPaquete.setInt(4, idPaquete);
            
            int filasModificadasPaquete = psPaquete.executeUpdate();

            
            String consultaDetalle = "UPDATE detalle_paquete SET id_flor=?, cantidad=? WHERE id_paquete=?";
            PreparedStatement psDetalle = cn.prepareStatement(consultaDetalle);
            psDetalle.setInt(1, idFlor);
            psDetalle.setInt(2, cantidad);
            psDetalle.setInt(3, idPaquete);
            
            int filasModificadasDetalle = psDetalle.executeUpdate();
            
            if (filasModificadasPaquete > 0 && filasModificadasDetalle > 0) {
                cn.commit();
                JOptionPane.showMessageDialog(null, "Paquete modificado correctamente.");
                
                modelo.setValueAt(nombrePaquete, filaSeleccionada, 1);
                modelo.setValueAt(descripcion, filaSeleccionada, 2);
                modelo.setValueAt(precio, filaSeleccionada, 3);
                modelo.setValueAt(nombreFlor, filaSeleccionada, 4);
                modelo.setValueAt(cantidad, filaSeleccionada, 5);
                return true;
            } else {
                cn.rollback();
                JOptionPane.showMessageDialog(null, "Error al modificar paquete.");
                return false;
            }
        } catch (SQLException e) {
            try {
                cn.rollback();
            } catch (SQLException ex) {
                System.out.println("Error al revertir la transacción: " + ex.getMessage());
            }
            JOptionPane.showMessageDialog(null, "Error al modificar paquete: " + e.getMessage());
            return false;
        } finally {
            try {
                cn.setAutoCommit(true);
            } catch (SQLException e) {
                System.out.println("Error al restablecer el auto-commit: " + e.getMessage());
            }
        }
    }
}


}
