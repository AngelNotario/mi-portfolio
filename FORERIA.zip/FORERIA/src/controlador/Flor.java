
package controlador;

public class Flor {
    private int idFlor;
    private String nombre;
    private String tipo;
    private String color;
    private double precio;

    // Constructor
    public Flor(int idFlor, String nombre, String tipo, String color, double precio) {
        this.idFlor = idFlor;
        this.nombre = nombre;
        this.tipo = tipo;
        this.color = color;
        this.precio = precio;
    }

    // Getters y Setters
    public int getIdFlor() {
        return idFlor;
    }

    public void setIdFlor(int idFlor) {
        this.idFlor = idFlor;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return nombre;
    }
}

