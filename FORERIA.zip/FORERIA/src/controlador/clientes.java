
package controlador;

import java.sql.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;


public class clientes {
    
public boolean registrarCliente(String nombre, String apellidos, String correo, String telefono, String direccion) {
  
    if (!validarCorreo(correo)) {
        JOptionPane.showMessageDialog(null, "Correo electrónico no válido.");
        return false;
    }

    
    if (!validarTelefono(telefono)) {
        JOptionPane.showMessageDialog(null, "Número de teléfono no válido.");
        return false;
    }

    conexion con = new conexion();
    Connection cn = con.conectar();

    if (cn == null) {
        JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos.");
        return false;
    }
    
    try {
        String consulta = "INSERT INTO clientes (nombre, apellidos, correo, telefono, direccion) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement ps = cn.prepareStatement(consulta);
        ps.setString(1, nombre);
        ps.setString(2, apellidos);
        ps.setString(3, correo);
        ps.setString(4, telefono);
        ps.setString(5, direccion);
        
        int filasInsertadas = ps.executeUpdate();
        if (filasInsertadas > 0) {
            System.out.println("Cliente registrado correctamente.");
           
            return true;
        } else {
            System.out.println("Error al registrar cliente.");
            return false;
        }
    } catch (SQLException e) {
        System.out.println("Error SQL al registrar cliente: " + e.getMessage());
        return false;
    }
}

public boolean validarCorreo(String correo) {
    String regex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
    Pattern pattern = Pattern.compile(regex);
    Matcher matcher = pattern.matcher(correo);
    return matcher.matches();
}

public boolean validarTelefono(String telefono) {
    String regex = "^[0-9]{10}$"; 
    Pattern pattern = Pattern.compile(regex);
    Matcher matcher = pattern.matcher(telefono);
    return matcher.matches();
}

public boolean modificarCliente(JTable table) {
    DefaultTableModel modelo = (DefaultTableModel) table.getModel();
    int filaSeleccionada = table.getSelectedRow();
    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(null, "Selecciona un cliente para modificar.");
        return false;
    } else {
        int idCliente = (int) modelo.getValueAt(filaSeleccionada, 0);
        String nombre = (String) modelo.getValueAt(filaSeleccionada, 1);
        String apellidos = (String) modelo.getValueAt(filaSeleccionada, 2);
        String correo = (String) modelo.getValueAt(filaSeleccionada, 3);
        String telefono = (String) modelo.getValueAt(filaSeleccionada, 4);
        String direccion = (String) modelo.getValueAt(filaSeleccionada, 5);

        if (!validarCorreo(correo)) {
            JOptionPane.showMessageDialog(null, "Correo electrónico no válido.");
            return false;
        }

         conexion con = new conexion();
    Connection cn = con.conectar();
        
        try {
            String consulta = "UPDATE clientes SET nombre=?, apellidos=?, correo=?, telefono=?, direccion=? WHERE id_cliente=?";
            PreparedStatement ps = cn.prepareStatement(consulta);
            ps.setString(1, nombre);
            ps.setString(2, apellidos);
            ps.setString(3, correo);
            ps.setString(4, telefono);
            ps.setString(5, direccion);
            ps.setInt(6, idCliente);
            
            int filasModificadas = ps.executeUpdate();
            if (filasModificadas > 0) {
                JOptionPane.showMessageDialog(null, "Cliente modificado correctamente.");
                modelo.setValueAt(nombre, filaSeleccionada, 1);
                modelo.setValueAt(apellidos, filaSeleccionada, 2);
                modelo.setValueAt(correo, filaSeleccionada, 3);
                modelo.setValueAt(telefono, filaSeleccionada, 4);
                modelo.setValueAt(direccion, filaSeleccionada, 5);
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Error al modificar cliente.");
                return false;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar cliente: " + e.getMessage());
            return false;
        }
    }
}



 
public boolean eliminarCliente(JTable table) {
    DefaultTableModel modelo = (DefaultTableModel) table.getModel();
    int filaSeleccionada = table.getSelectedRow();
    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(null, "Selecciona un cliente para eliminar.");
        return false;
    } else {
        int idCliente = (int) modelo.getValueAt(filaSeleccionada, 0);
        String sql = "DELETE FROM clientes WHERE id_cliente = ?";
        conexion con = new conexion();
        try {
            Connection cn = con.conectar();
            PreparedStatement ps = cn.prepareStatement(sql);
            ps.setInt(1, idCliente);
            int filasEliminadas = ps.executeUpdate();
            if (filasEliminadas > 0) {
                JOptionPane.showMessageDialog(null, "Cliente eliminado correctamente.");
                modelo.removeRow(filaSeleccionada);
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Error al eliminar cliente.");
                return false;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar cliente: " + e.getMessage());
            return false;
        }
    }
}


public void mostrarClientes(JTable table, String b) {
    String buscar = b;
    conexion con = new conexion();
    DefaultTableModel modelo = new DefaultTableModel();
    TableRowSorter<TableModel> ordenarTabla = new TableRowSorter<TableModel>(modelo);
    table.setRowSorter(ordenarTabla);

    modelo.addColumn("Identificador");
    modelo.addColumn("Nombre");
    modelo.addColumn("Apellido");
    modelo.addColumn("Correo Electrónico");
    modelo.addColumn("Teléfono");
    modelo.addColumn("Dirección");

    table.setModel(modelo);

    String sql = "SELECT * FROM clientes WHERE nombre LIKE ?";
    try {
        Connection cn = con.conectar();
        PreparedStatement ps = cn.prepareStatement(sql);
        ps.setString(1, "%" + buscar + "%");
        ResultSet rs = ps.executeQuery();
        Object[] datos = new Object[6];
        while (rs.next()) {
            datos[0] = rs.getInt("id_cliente");
            datos[1] = rs.getString("nombre");
            datos[2] = rs.getString("apellidos");
            datos[3] = rs.getString("correo");
            datos[4] = rs.getString("telefono");
            datos[5] = rs.getString("direccion");
            modelo.addRow(datos);
        }
        table.setModel(modelo);
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al mostrar los registros: " + e.getMessage());
    }
}


}
