
package controlador;

import java.sql.*;

public class conexion {

        public static Connection conectar() {
        Connection conectar = null;
        String usuario = "root";
        String password = "12345678";
        String cadena = "jdbc:mysql://localhost:3306/floreria";

        try {        
            Class.forName("com.mysql.cj.jdbc.Driver");
            conectar = DriverManager.getConnection(cadena, usuario, password);    
            return conectar;
        } catch (ClassNotFoundException e) {
            System.out.println("Error al cargar el driver JDBC: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Error en la conexión a la base de datos: " + e.getMessage());
        }

        return null;
    }
    
}

